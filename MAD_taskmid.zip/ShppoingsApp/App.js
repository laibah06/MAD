import React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './Frontend/screens/HomeScreen';
import WinterScreen from './Frontend/screens/WinterScreen';
import SummerScreen from './Frontend/screens/SummerScreen';
import PerfumesScreen from './Frontend/screens/PerfumesScreen';
import SaleScreen from './Frontend/screens/SaleScreen';
import WinterSubScreen from './Frontend/screens/WinterSubScreen';
import SummerSubScreen from './Frontend/screens/SummerSubScreen';
import PerfumesSubScreen from './Frontend/screens/PerfumesSubScreen';

const Stack = createNativeStackNavigator();

const CustomTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#FF6B6B',
    background: '#0A0A0A',
    card: '#1A1A1A',
    text: '#FFFFFF',
    border: '#333333',
  },
};

export default function App() {
  return (
    <NavigationContainer theme={CustomTheme}>
      <Stack.Navigator 
        initialRouteName="Splash"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#1A1A1A',
          },
          headerTintColor: '#FF6B6B',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen name="Splash" component={SplashScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Winter" component={WinterScreen} options={{ title: 'Winter Collection' }} />
        <Stack.Screen name="Summer" component={SummerScreen} options={{ title: 'Summer Collection' }} />
        <Stack.Screen name="Perfumes" component={PerfumesScreen} options={{ title: 'Perfumes Collection' }} />
        <Stack.Screen name="Sale" component={SaleScreen} options={{ title: 'Sale Items' }} />
        <Stack.Screen name="WinterSub" component={WinterSubScreen} options={{ title: 'Winter Collection' }} />
        <Stack.Screen name="SummerSub" component={SummerSubScreen} options={{ title: 'Summer Collection' }} />
        <Stack.Screen name="PerfumesSub" component={PerfumesSubScreen} options={{ title: 'Perfumes' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}