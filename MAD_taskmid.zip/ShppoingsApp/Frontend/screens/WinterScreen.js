import React from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  ScrollView, 
  StyleSheet, 
  ImageBackground,
  Dimensions 
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const { width } = Dimensions.get('window');

const WinterScreen = ({ navigation }) => {
  const subcategories = [
    {
      name: 'Stitched',
      screen: 'WinterSub',
      image: 'https://i.pinimg.com/1200x/6a/f0/e1/6af0e15608b4a84e324dd4852fad72f9.jpg',
    },
    {
      name: 'Unstitched',
      screen: 'WinterSub', 
      image: 'https://i.pinimg.com/1200x/7a/e6/3f/7ae63f9a6702cdb818ec6a5c7b96e7c4.jpg',
    }
  ];

  return (
    <View style={styles.container}>
      {/* CLEAN HEADER */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Icon name="arrow-back-ios" size={20} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Winter</Text>
        <View style={styles.headerIcons}>
          <Icon name="ac-unit" size={22} color="#4FC3F7" />
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        
        {/* HERO SECTION */}
        <View style={styles.heroSection}>
          <Text style={styles.heroTitle}>Winter Collection</Text>
          <Text style={styles.heroSubtitle}>Embrace the cold with style</Text>
        </View>

        {/* SUBCATEGORIES */}
        <View style={styles.categoriesContainer}>
          <View style={styles.categoriesList}>
            {subcategories.map((category, index) => (
              <TouchableOpacity 
                key={index}
                style={styles.categoryItem}
                onPress={() => navigation.navigate(category.screen, { type: category.name })}
              >
                <ImageBackground 
                  source={{ uri: category.image }}
                  style={styles.categoryImage}
                  imageStyle={styles.categoryImageStyle}
                >
                  <View style={styles.categoryGradient} />
                  
                  <View style={styles.categoryContent}>
                    <Text style={styles.categoryName}>{category.name}</Text>
                    <Text style={styles.exploreText}>Explore</Text>
                  </View>
                </ImageBackground>
              </TouchableOpacity>
            ))}
          </View>
        </View>

      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0A',
  },
  // CLEAN HEADER
  header: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 10,
    backgroundColor: 'rgba(26, 26, 26, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: '#1E1E1E',
  },
  backButton: {
    padding: 5,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  headerIcons: {
    width: 30,
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  // HERO SECTION
  heroSection: {
    padding: 30,
    alignItems: 'center',
    backgroundColor: 'rgba(30, 30, 30, 0.6)',
    marginBottom: 10,
  },
  heroTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#4FC3F7',
    textAlign: 'center',
    fontWeight: '500',
  },
  // CATEGORIES
  categoriesContainer: {
    padding: 20,
  },
  categoriesList: {
    gap: 15,
  },
  categoryItem: {
    height: 140,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  categoryImage: {
    flex: 1,
  },
  categoryImageStyle: {
    borderRadius: 16,
  },
  categoryGradient: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  categoryContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  categoryName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  exploreText: {
    fontSize: 14,
    color: '#4FC3F7',
    fontWeight: '500',
  },
});

export default WinterScreen;