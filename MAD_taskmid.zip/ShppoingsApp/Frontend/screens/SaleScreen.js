import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ImageBackground, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const SaleScreen = ({ navigation }) => {
  const saleItems = [
    {
      id: 1,
      name: 'Designer Dress',
      price: 'Rs.2500',
      originalPrice: 'Rs.6000',
      discount: '30% OFF',
      image: 'https://i.pinimg.com/736x/d2/e5/d1/d2e5d16fa1b1d679f2c6a0ebbafbc8fe.jpg',
      category: 'Winter'
    },
    {
      id: 2,
      name: 'Summer kurta',
      price: 'Rs. 2000',
      originalPrice: 'Rs.5000',
      discount: '40% OFF',
      image: 'https://i.pinimg.com/736x/28/54/c5/2854c5c5ba8afd211accd6b822f70e8c.jpg',
      category: 'Summer'
    },
    {
      id: 3,
      name: 'Men\'s Perfume',
      price: 'Rs.3000',
      originalPrice: '4500',
      discount: '30% OFF',
      image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=400',
      category: 'Perfumes'
    },
    {
      id: 4,
      name: 'Winter Collection',
      price: 'Rs 3000',
      originalPrice: 'Rs.5000',
      discount: '35% OFF',
      image: 'https://i.pinimg.com/1200x/18/9f/02/189f023a0c2d1ac92448f0c2cc0792e1.jpg',
      category: 'Winter'
    }
  ];

  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=800' }}
      style={styles.container}
    >
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Sale Items</Text>
        <Text style={styles.subtitle}>Limited time offers</Text>
        
        <View style={styles.saleGrid}>
          {saleItems.map((item) => (
            <TouchableOpacity key={item.id} style={styles.productCard}>
              <View style={styles.discountBadge}>
                <Text style={styles.discountText}>{item.discount}</Text>
              </View>
              <Image source={{ uri: item.image }} style={styles.productImage} />
              <View style={styles.productInfo}>
                <Text style={styles.productName}>{item.name}</Text>
                <Text style={styles.productCategory}>{item.category}</Text>
                <View style={styles.priceContainer}>
                  <Text style={styles.currentPrice}>{item.price}</Text>
                  <Text style={styles.originalPrice}>{item.originalPrice}</Text>
                </View>
                <TouchableOpacity style={styles.addToCartButton}>
                  <Icon name="add-shopping-cart" size={18} color="#FFFFFF" />
                  <Text style={styles.addToCartText}>Add to Cart</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(10, 10, 10, 0.85)',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#FF6B6B',
    textAlign: 'center',
    marginBottom: 30,
  },
  saleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    width: '48%',
    backgroundColor: 'rgba(30, 30, 30, 0.9)',
    borderRadius: 15,
    marginBottom: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  discountBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    zIndex: 1,
  },
  discountText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  productImage: {
    width: '100%',
    height: 150,
  },
  productInfo: {
    padding: 12,
  },
  productName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 12,
    color: '#CCCCCC',
    marginBottom: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  currentPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF6B6B',
    marginRight: 8,
  },
  originalPrice: {
    fontSize: 12,
    color: '#888',
    textDecorationLine: 'line-through',
  },
  addToCartButton: {
    flexDirection: 'row',
    backgroundColor: '#FF6B6B',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default SaleScreen;