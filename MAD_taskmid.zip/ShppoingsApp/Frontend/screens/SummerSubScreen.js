import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ImageBackground, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const SummerSubScreen = ({ route, navigation }) => {
  const { type = 'Pret' } = route.params || {};
  
  // Pret ke liye products
  const pretProducts = [
    {
      id: 1,
      name: 'Floral Dress',
      price: 'Rs.3500',
      image: 'https://i.pinimg.com/1200x/ac/6c/46/ac6c46a7ec5ecd9f52278f0a2785da66.jpg'
    },
    {
      id: 2,
      name: 'Cotton Top',
      price: 'Rs.1800',
      image: 'https://i.pinimg.com/736x/62/9b/4a/629b4a5d5c5e5d5c5d5c5d5c5d5c5d5c.jpg'
    },
    {
      id: 3,
      name: 'Beach Wear',
      price: 'Rs.2200',
      image: 'https://i.pinimg.com/736x/73/ac/7d/73ac7d5d5c5e5d5c5d5c5d5c5d5c5d5c.jpg'
    },
    {
      id: 4,
      name: 'Summer Skirt',
      price: 'Rs.2000',
      image: 'https://i.pinimg.com/736x/84/bd/af/84bdaf5d5c5e5d5c5d5c5d5c5d5c5d5c.jpg'
    }
  ];

  // Unstitched ke liye products
  const unstitchedProducts = [
    {
      id: 1,
      name: 'Cotton Lawn',
      price: 'Rs.1200',
      image: 'https://i.pinimg.com/736x/1e/7e/ec/1e7eecd03eed16efd60d51a2d9037129.jpg'
    },
    {
      id: 2,
      name: 'Linen Fabric',
      price: 'Rs.1500',
      image: 'https://i.pinimg.com/1200x/2b/cc/10/2bcc104842c75f90a24decd536f408b6.jpg'
    },
    {
      id: 3,
      name: 'Chiffon Cloth',
      price: 'Rs.1800',
      image: 'https://i.pinimg.com/1200x/fb/62/38/fb6238ab5c06c16c7c143b0340f1b7df.jpg'
    },
    {
      id: 4,
      name: 'Voile Fabric',
      price: 'Rs.1300',
      image: 'https://i.pinimg.com/1200x/c0/bb/c2/c0bbc27232762b21eee621cec75bd223.jpg'
    }
  ];

  // Type ke hisaab se products select karo
  const products = type === 'Pret' ? pretProducts : unstitchedProducts;
  const subtitle = type === 'Pret' ? 'Ready to wear summer collection' : 'Light fabrics for summer stitching';

  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=800' }}
      style={styles.container}
    >
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Summer {type}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
        
        <View style={styles.productsGrid}>
          {products.map((product) => (
            <View key={product.id} style={styles.productCard}>
              <Image source={{ uri: product.image }} style={styles.productImage} />
              <View style={styles.productInfo}>
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productPrice}>{product.price}</Text>
                <TouchableOpacity style={styles.addToCartButton}>
                  <Icon name="add-shopping-cart" size={16} color="#FFFFFF" />
                  <Text style={styles.addToCartText}>Add to Cart</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(10, 10, 10, 0.85)',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#FFD54F',
    textAlign: 'center',
    marginBottom: 30,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    width: '48%',
    backgroundColor: 'rgba(30, 30, 30, 0.9)',
    borderRadius: 15,
    marginBottom: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  productImage: {
    width: '100%',
    height: 150,
  },
  productInfo: {
    padding: 12,
  },
  productName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFD54F',
    marginBottom: 10,
  },
  addToCartButton: {
    flexDirection: 'row',
    backgroundColor: '#FFD54F',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartText: {
    color: '#000000',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default SummerSubScreen;