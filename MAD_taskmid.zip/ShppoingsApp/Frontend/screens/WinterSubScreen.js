import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ImageBackground, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const WinterSubScreen = ({ route, navigation }) => {
  const { type = 'Pret' } = route.params || {};
  
  // Pret ke liye products
  const pretProducts = [
    {
      id: 1,
      name: 'Woolen Dress',
      price: 'Rs.4000',
      image: 'https://i.pinimg.com/736x/b9/02/9f/b9029f742cab3d853d8e0dc17699669c.jpg'
    },
    {
      id: 2,
      name: 'Winter Coat',
      price: 'Rs.6000',
      image: 'https://i.pinimg.com/736x/81/ff/1d/81ff1dcc8548270bb3b7a14bdccdf1a3.jpg'
    },
    {
      id: 3,
      name: 'Knit Sweater',
      price: 'Rs.3500',
      image: 'https://i.pinimg.com/736x/f4/39/8b/f4398b23456bc9ebae0b329f5641934f.jpg'
    },
    {
      id: 4,
      name: 'Faux Fur Jacket',
      price: 'Rs.3800',
      image: 'https://i.pinimg.com/736x/b0/01/08/b0010838ad4daac233e7f019040d80c7.jpg'
    }
  ];

  // Unstitched ke liye products
  const unstitchedProducts = [
    {
      id: 1,
      name: 'Woolen Suit Fabric',
      price: 'Rs.2500',
      image: 'https://i.pinimg.com/1200x/d4/61/04/d46104a12a8fabc897fb5a37f23afc39.jpg'
    },
    {
      id: 2,
      name: 'Cashmere Cloth',
      price: 'Rs.4500',
      image: 'https://i.pinimg.com/1200x/46/56/b2/4656b244269cac5a3522688db9857ece.jpg'
    },
    {
      id: 3,
      name: 'Designer Lawn',
      price: 'Rs.1800',
      image: 'https://i.pinimg.com/1200x/7c/f6/4b/7cf64bd2af27142776b1953c8bbf99d3.jpg'
    },
    {
      id: 4,
      name: 'Winter Suiting',
      price: 'Rs.3200',
      image: 'https://i.pinimg.com/1200x/a8/0e/50/a80e50a3b5f0061b8d942863f2a60c5d.jpg'
    }
  ];

  const products = type === 'Pret' ? pretProducts : unstitchedProducts;
  const subtitle = type === 'Pret' ? 'Ready to wear collection' : 'Premium fabrics for stitching';

  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=800' }}
      style={styles.container}
    >
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Winter {type}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
        
        <View style={styles.productsGrid}>
          {products.map((product) => (
            <View key={product.id} style={styles.productCard}>
              <Image source={{ uri: product.image }} style={styles.productImage} />
              <View style={styles.productInfo}>
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productPrice}>{product.price}</Text>
                <TouchableOpacity style={styles.addToCartButton}>
                  <Icon name="add-shopping-cart" size={16} color="#FFFFFF" />
                  <Text style={styles.addToCartText}>Add to Cart</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(10, 10, 10, 0.85)',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#4FC3F7',
    textAlign: 'center',
    marginBottom: 30,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    width: '48%',
    backgroundColor: 'rgba(30, 30, 30, 0.9)',
    borderRadius: 15,
    marginBottom: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  productImage: {
    width: '100%',
    height: 150,
  },
  productInfo: {
    padding: 12,
  },
  productName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4FC3F7',
    marginBottom: 10,
  },
  addToCartButton: {
    flexDirection: 'row',
    backgroundColor: '#4FC3F7',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default WinterSubScreen;