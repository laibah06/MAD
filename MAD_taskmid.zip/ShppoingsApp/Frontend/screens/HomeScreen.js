import React, { useRef, useEffect } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  ScrollView, 
  StyleSheet, 
  ImageBackground, 
  Animated,
  Dimensions 
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(-100)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      })
    ]).start();
  }, []);

  const categories = [
    { 
      name: 'Winter', 
      icon: 'ac-unit', 
      screen: 'Winter',
      image: 'https://i.pinimg.com/736x/01/a7/0b/01a70b94b6c50a98f33aecde39f4f770.jpg'
    },
    { 
      name: 'Summer', 
      icon: 'wb-sunny', 
      screen: 'Summer',
      image: 'https://i.pinimg.com/736x/c2/cd/f0/c2cdf0216387fcb6d7b24ee15b95d4f4.jpg'
    },
    { 
      name: 'Perfumes', 
      icon: 'spa', 
      screen: 'Perfumes',
      image: 'https://i.pinimg.com/1200x/6f/09/fb/6f09fbb96199d693ae43c89a1edb908d.jpg'
    },
    { 
      name: 'Sale', 
      icon: 'local-offer', 
      screen: 'Sale',
      image: 'https://i.pinimg.com/736x/83/0c/1a/830c1acb6e50bf3049d3dddc6d6bf4b4.jpg'
    },
  ];

  return (
    <ImageBackground 
      source={{ uri: 'https://i.pinimg.com/736x/64/0c/f6/640cf652877f4c6a65268b04125a76b9.jpg' }}
      style={styles.container}
    >
      {/* RECTANGLE HEADER */}
      <Animated.View 
        style={[
          styles.headerRectangle,
          { 
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }]
          }
        ]}
      >
        <View style={styles.headerContent}>
          <View style={styles.appInfo}>
            <Icon name="store" size={24} color="#FF6B6B" style={styles.storeIcon} />
            <Text style={styles.appName}>StyleGo</Text>
          </View>
          
          <View style={styles.headerStats}>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>4</Text>
              <Text style={styles.statLabel}>Categories</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>50+</Text>
              <Text style={styles.statLabel}>Products</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Icon name="local-offer" size={16} color="#FF6B6B" />
              <Text style={styles.statLabel}>Sale</Text>
            </View>
          </View>
        </View>
      </Animated.View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        
        {/* Welcome Text */}
        <Animated.View 
          style={[
            styles.welcomeSection,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }
          ]}
        >
          <Text style={styles.welcomeTitle}>Welcome to StyleGo</Text>
          <Text style={styles.welcomeSubtitle}>Discover the latest fashion trends</Text>
        </Animated.View>

        {/* Sale Banner */}
        <Animated.View 
          style={[
            styles.saleBanner,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }
          ]}
        >
          <View style={styles.bannerContent}>
            <Text style={styles.saleText}>FLASH SALE</Text>
            <Text style={styles.discountText}>30% OFF</Text>
            <Text style={styles.saleSubText}>On New Collections</Text>
          </View>
        </Animated.View>

        {/* Categories */}
        <Text style={styles.sectionTitle}>Shop Categories</Text>
        <View style={styles.categoriesGrid}>
          {categories.map((category, index) => (
            <Animated.View
              key={category.name}
              style={[
                styles.categoryCard,
                {
                  opacity: fadeAnim,
                  transform: [
                    { 
                      translateY: slideAnim.interpolate({
                        inputRange: [0, 50],
                        outputRange: [0, index % 2 === 0 ? -15 : 15]
                      })
                    }
                  ]
                }
              ]}
            >
              <TouchableOpacity 
                style={styles.categoryButton}
                onPress={() => navigation.navigate(category.screen)}
              >
                <ImageBackground 
                  source={{ uri: category.image }}
                  style={styles.categoryImage}
                  imageStyle={styles.categoryImageStyle}
                >
                  <View style={styles.categoryOverlay} />
                  <View style={styles.categoryContent}>
                    <Icon name={category.icon} size={32} color="#FFFFFF" />
                    <Text style={styles.categoryText}>{category.name}</Text>
                  </View>
                </ImageBackground>
              </TouchableOpacity>
            </Animated.View>
          ))}
        </View>

      </ScrollView>
    </ImageBackground>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  
});

export default HomeScreen;