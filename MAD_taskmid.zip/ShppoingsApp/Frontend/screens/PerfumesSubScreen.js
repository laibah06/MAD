import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ImageBackground, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const PerfumesSubScreen = ({ route, navigation }) => {
  const { type = 'Men' } = route.params || {};
  
  // Men ke liye perfumes
  const menPerfumes = [
    {
      id: 1,
      name: 'Junaid Jamshed',
      price: 'Rs.3500',
      image: 'https://i.pinimg.com/736x/be/25/bb/be25bb1e3f7b18b81625f33354d05eb4.jpg'
    },
    {
      id: 2,
      name: 'J.',
      price: 'Rs.4200',
      image: 'https://i.pinimg.com/736x/15/e4/2e/15e42e2d838b4ddfeb9b4a6054584aae.jpg'
    },
    {
      id: 3,
      name: 'J. Black',
      price: 'Rs.3800',
      image: 'https://i.pinimg.com/736x/2f/4b/13/2f4b13d77c87f9fcc2229bb731bac6ba.jpg'
    },
    {
      id: 4,
      name: 'Scentology',
      price: 'Rs.3200',
      image: 'https://i.pinimg.com/736x/31/0a/ef/310aef918027f8efb508e074173c3ef8.jpg'
    }
  ];

  // Women ke liye perfumes
  const womenPerfumes = [
    {
      id: 1,
      name: 'Gulab',
      price: 'Rs.2800',
      image: 'https://i.pinimg.com/1200x/0d/f7/c4/0df7c4036c8e5c11bd257f6ce1e09ea9.jpg'
    },
    {
      id: 2,
      name: 'Chambeli',
      price: 'Rs.3200',
      image: 'https://i.pinimg.com/736x/bb/b7/8a/bbb78a91d03c7f1bae5905a7193d53fc.jpg'
    },
    {
      id: 3,
      name: 'Moti',
      price: 'Rs.3500',
      image: 'https://i.pinimg.com/1200x/15/d2/8d/15d28d722d5d581f368130ad55096446.jpg'
    },
    {
      id: 4,
      name: 'Sandalwood',
      price: 'Rs.3000',
      image: 'https://i.pinimg.com/736x/69/f4/32/69f432422b36fef22ec1da01e02fe094.jpg'
    }
  ];

  // Type ke hisaab se perfumes select karo
  const perfumes = type === 'Men' ? menPerfumes : womenPerfumes;
  const subtitle = type === 'Men' ? 'Premium fragrances for men' : 'Elegant scents for women';

  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1589994965851-a8f479c573a9?w=800' }}
      style={styles.container}
    >
      <ScrollView style={styles.content}>
        <Text style={styles.title}>{type} Perfumes</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
        
        <View style={styles.perfumesGrid}>
          {perfumes.map((perfume) => (
            <View key={perfume.id} style={styles.perfumeCard}>
              <Image source={{ uri: perfume.image }} style={styles.perfumeImage} />
              <View style={styles.perfumeInfo}>
                <Text style={styles.perfumeName}>{perfume.name}</Text>
                <Text style={styles.perfumePrice}>{perfume.price}</Text>
                <TouchableOpacity style={styles.addToCartButton}>
                  <Icon name="add-shopping-cart" size={16} color="#FFFFFF" />
                  <Text style={styles.addToCartText}>Add to Cart</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    backgroundColor: 'rgba(10, 10, 10, 0.85)',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#BA68C8',
    textAlign: 'center',
    marginBottom: 30,
  },
  perfumesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  perfumeCard: {
    width: '48%',
    backgroundColor: 'rgba(30, 30, 30, 0.9)',
    borderRadius: 15,
    marginBottom: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  perfumeImage: {
    width: '100%',
    height: 150,
  },
  perfumeInfo: {
    padding: 12,
  },
  perfumeName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  perfumePrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#BA68C8',
    marginBottom: 10,
  },
  addToCartButton: {
    flexDirection: 'row',
    backgroundColor: '#BA68C8',
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default PerfumesSubScreen;