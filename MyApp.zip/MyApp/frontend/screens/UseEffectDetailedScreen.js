import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const UseEffectDetailedScreen = () => {
  const [count, setCount] = useState(0);
  const [name, setName] = useState('');
  const [timer, setTimer] = useState(0);
  const [logs, setLogs] = useState([]);

  const addLog = (message) => {
    setLogs(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  // Case 1: Empty dependency array - runs once
  useEffect(() => {
    addLog('🔄 Case 1: Empty [] - Component mounted (runs once)');
    return () => addLog('🧹 Case 1: Cleanup - Component unmounted');
  }, []);

  // Case 2: With dependency - runs when count changes
  useEffect(() => {
    addLog(`🔢 Case 2: With [count] - Count changed to: ${count}`);
  }, [count]);

  // Case 3: No dependency array - runs on every render
  useEffect(() => {
    addLog('🎯 Case 3: No array - Runs on every render');
  });

  // Case 4: With multiple dependencies
  useEffect(() => {
    if (name) {
      addLog(`📝 Case 4: With [name] - Name changed to: ${name}`);
    }
  }, [name]);

  // Timer effect
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prev => prev + 1);
    }, 1000);

    return () => {
      clearInterval(interval);
      addLog('⏰ Timer cleaned up');
    };
  }, []);

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>useEffect All Cases</Text>
      
      <View style={globalStyles.card}>
        <Text>Counter: {count}</Text>
        <TouchableOpacity style={globalStyles.button} onPress={() => setCount(count + 1)}>
          <Text style={globalStyles.buttonText}>Increment Count</Text>
        </TouchableOpacity>
      </View>

      <View style={globalStyles.card}>
        <Text>Name: {name}</Text>
        <TouchableOpacity style={globalStyles.button} onPress={() => setName('Kausar')}>
          <Text style={globalStyles.buttonText}>Set Name to "Kausar"</Text>
        </TouchableOpacity>
      </View>

      <View style={globalStyles.card}>
        <Text>Timer: {timer} seconds</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>useEffect Cases Summary:</Text>
        <Text>1. [] - Runs once on mount</Text>
        <Text>2. [count] - Runs when count changes</Text>
        <Text>3. No array - Runs on every render</Text>
        <Text>4. [name] - Runs when name changes</Text>
        <Text>5. Cleanup - Runs on unmount</Text>
      </View>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {logs.map((log, index) => (
          <Text key={index} style={globalStyles.card}>{log}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default UseEffectDetailedScreen;