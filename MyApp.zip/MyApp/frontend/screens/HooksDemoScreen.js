import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';

const HooksDemoScreen = () => {
  const [count, setCount] = useState(0);
  const [timer, setTimer] = useState(0);

  
  useEffect(() => {
    console.log('Component mounted - runs once');
  }, []);

  
  useEffect(() => {
    console.log(`Count changed to: ${count}`);
  }, [count]);

 
  useEffect(() => {
    console.log('Runs on every render');
  });

 
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval); 
  }, []);

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Hooks Demo</Text>
      
      <View style={globalStyles.card}>
        <Text>useState Counter: {count}</Text>
        <TouchableOpacity 
          style={globalStyles.button}
          onPress={() => setCount(count + 1)}
        >
          <Text style={globalStyles.buttonText}>Increment</Text>
        </TouchableOpacity>
      </View>

      <View style={globalStyles.card}>
        <Text>useEffect Timer: {timer} seconds</Text>
      </View>

      <View style={globalStyles.card}>
        <Text>useEffect Cases:</Text>
        <Text>1. Empty [] - Runs once on mount</Text>
        <Text>2. With [count] - Runs when count changes</Text>
        <Text>3. No array - Runs on every render</Text>
      </View>
    </View>
  );
};

export default HooksDemoScreen;