import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';


const useDataFetcher = (url) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);


        setTimeout(() => {
          setData({ message: `Data from ${url}`, timestamp: new Date() });
          setLoading(false);
        }, 2000);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchData();
  }, [url]);

  return { data, loading, error };
};



const useCounter = (initialValue = 0) => {
  const [count, setCount] = useState(initialValue);

  const increment = () => setCount(prev => prev + 1);
  const decrement = () => setCount(prev => prev - 1);
  const reset = () => setCount(initialValue);

  return { count, increment, decrement, reset };
};

const CustomHooksScreen = () => {
  const { data, loading, error } = useDataFetcher('https://api.example.com/data');
  const { count, increment, decrement, reset } = useCounter(0);

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Custom Hooks Demo</Text>
      
      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Custom Hook 1: useCounter</Text>
        <Text>Count: {count}</Text>
        <TouchableOpacity style={globalStyles.button} onPress={increment}>
          <Text style={globalStyles.buttonText}>Increment</Text>
        </TouchableOpacity>
        <TouchableOpacity style={globalStyles.button} onPress={decrement}>
          <Text style={globalStyles.buttonText}>Decrement</Text>
        </TouchableOpacity>
        <TouchableOpacity style={globalStyles.button} onPress={reset}>
          <Text style={globalStyles.buttonText}>Reset</Text>
        </TouchableOpacity>
      </View>

      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Custom Hook 2: useDataFetcher</Text>
        {loading && <Text>Loading...</Text>}
        {error && <Text>Error: {error}</Text>}
        {data && <Text>Data: {JSON.stringify(data)}</Text>}
      </View>

      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Custom Hook Rules:</Text>
        <Text>• Start with "use" prefix</Text>
        <Text>• Can use other hooks inside</Text>
        <Text>• Share logic, not state</Text>
        <Text>• Each call is independent</Text>
      </View>
    </View>
  );
};

export default CustomHooksScreen;