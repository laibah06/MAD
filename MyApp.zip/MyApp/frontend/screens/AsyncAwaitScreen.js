import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const AsyncAwaitScreen = () => {
  const [output, setOutput] = useState([]);
  const [loading, setLoading] = useState(false);

  const addOutput = (text) => {
    setOutput(prev => [...prev, text]);
  };

  const simulateAPICall = () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve('Data fetched successfully!');
      }, 2000);
    });
  };

  const demoAsyncAwait = async () => {
    setOutput([]);
    setLoading(true);
    
    try {
      addOutput('Fetching data...');
      const result = await simulateAPICall();
      addOutput(`Result: ${result}`);
      
     
      addOutput('Fetching more data...');
      const result2 = await simulateAPICall();
      addOutput(`Result 2: ${result2}`);
      
    } catch (error) {
      addOutput(`Error: ${error}`);
    } finally {
      setLoading(false);
      addOutput('All operations completed!');
    }
  };

  const demoParallelRequests = async () => {
    setOutput([]);
    setLoading(true);
    
    try {
      addOutput('Starting parallel requests...');
      
      const [result1, result2] = await Promise.all([
        simulateAPICall(),
        simulateAPICall()
      ]);
      
      addOutput(`Result 1: ${result1}`);
      addOutput(`Result 2: ${result2}`);
      addOutput('Both requests completed!');
      
    } catch (error) {
      addOutput(`Error: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Async/Await Demo</Text>
      
      <TouchableOpacity 
        style={[globalStyles.button, loading && { opacity: 0.5 }]} 
        onPress={demoAsyncAwait}
        disabled={loading}
      >
        <Text style={globalStyles.buttonText}>
          {loading ? 'Loading...' : 'Demo Async/Await'}
        </Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={[globalStyles.button, loading && { opacity: 0.5 }]} 
        onPress={demoParallelRequests}
        disabled={loading}
      >
        <Text style={globalStyles.buttonText}>
          {loading ? 'Loading...' : 'Demo Parallel Requests'}
        </Text>
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {output.map((item, index) => (
          <Text key={index} style={globalStyles.card}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default AsyncAwaitScreen;