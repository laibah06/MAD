import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';

const DataPassingScreen = ({ navigation, route }) => {
  const [inputData, setInputData] = useState('');
  
  
  const receivedData = route.params?.data || 'No data received';

  
  const sendDataToNextScreen = () => {
    navigation.navigate('DataPassing', {
      data: inputData,
      timestamp: new Date().toISOString()
    });
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Data Passing Demo</Text>
      
      <Text>Received Data: {receivedData}</Text>
      
      <TextInput
        style={globalStyles.input}
        placeholder="Enter data to pass"
        value={inputData}
        onChangeText={setInputData}
      />
      
      <TouchableOpacity 
        style={globalStyles.button}
        onPress={sendDataToNextScreen}
      >
        <Text style={globalStyles.buttonText}>Send Data to Next Screen</Text>
      </TouchableOpacity>
    </View>
  );
};

export default DataPassingScreen;