import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const PromiseDemoScreen = () => {
  const [output, setOutput] = useState([]);

  const addOutput = (text) => {
    setOutput(prev => [...prev, text]);
  };

  const demoBasicPromise = () => {
    setOutput([]);
    addOutput('Creating promise...');
    
    const promise = new Promise((resolve, reject) => {
      setTimeout(() => {
        const success = Math.random() > 0.3;
        if (success) {
          resolve('Promise resolved successfully!');
        } else {
          reject('Promise rejected with error!');
        }
      }, 2000);
    });

    promise
      .then(result => addOutput(`Success: ${result}`))
      .catch(error => addOutput(`Error: ${error}`))
      .finally(() => addOutput('Promise completed!'));
  };

  const demoPromiseChaining = () => {
    setOutput([]);
    
    new Promise((resolve) => {
      setTimeout(() => resolve(2), 1000);
    })
    .then(number => {
      addOutput(`Step 1: ${number}`);
      return number + 3;
    })
    .then(number => {
      addOutput(`Step 2: ${number}`);
      return number * 2;
    })
    .then(number => {
      addOutput(`Step 3: ${number}`);
      return number - 1;
    })
    .then(final => {
      addOutput(`Final Result: ${final}`);
    });
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Promises Demo</Text>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoBasicPromise}>
        <Text style={globalStyles.buttonText}>Demo Basic Promise</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoPromiseChaining}>
        <Text style={globalStyles.buttonText}>Demo Promise Chaining</Text>
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {output.map((item, index) => (
          <Text key={index} style={globalStyles.card}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default PromiseDemoScreen;