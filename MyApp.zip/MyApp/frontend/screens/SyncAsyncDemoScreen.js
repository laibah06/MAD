import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const SyncAsyncDemoScreen = () => {
  const [output, setOutput] = useState([]);

  const addOutput = (text) => {
    setOutput(prev => [...prev, text]);
  };

  const demoSynchronous = () => {
    setOutput([]);
    addOutput('🔹 Synchronous Code Start');
    addOutput('Hello');
    addOutput('CS and SE');
    addOutput('Welcome to MAD Lecture');
    addOutput('🔹 Synchronous Code End');
  };

  const demoAsynchronous = () => {
    setOutput([]);
    addOutput('🔹 Asynchronous Code Start');
    addOutput('Start');
    
    setTimeout(() => {
      addOutput('Processing... (after 2 seconds)');
    }, 2000);
    
    addOutput('End');
    addOutput('🔹 Asynchronous Code - "End" printed immediately!');
  };

  const demoRealLifeExample = () => {
    setOutput([]);
    addOutput('📱 Real Life Example:');
    addOutput('Synchronous: Download files one by one');
    addOutput('Asynchronous: Download multiple files at once');
    addOutput('Async keeps UI responsive while tasks run in background');
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Sync vs Async JavaScript</Text>
      
      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Synchronous Code:</Text>
        <Text>• Runs line by line</Text>
        <Text>• Next line waits for previous</Text>
        <Text>• Can block UI</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Asynchronous Code:</Text>
        <Text>• Doesn't wait, moves to next line</Text>
        <Text>• Long tasks run in background</Text>
        <Text>• Keeps UI smooth and responsive</Text>
      </View>

      <TouchableOpacity style={globalStyles.button} onPress={demoSynchronous}>
        <Text style={globalStyles.buttonText}>Demo Synchronous Code</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoAsynchronous}>
        <Text style={globalStyles.buttonText}>Demo Asynchronous Code</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoRealLifeExample}>
        <Text style={globalStyles.buttonText}>Real Life Example</Text>
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {output.map((item, index) => (
          <Text key={index} style={globalStyles.card}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default SyncAsyncDemoScreen;