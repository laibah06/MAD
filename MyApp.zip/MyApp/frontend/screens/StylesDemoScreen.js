import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';

const StylesDemoScreen = () => {
  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Global Styles Demo</Text>
      
      <View style={globalStyles.card}>
        <Text>This card uses global styles</Text>
      </View>

      <TouchableOpacity style={globalStyles.button}>
        <Text style={globalStyles.buttonText}>Styled Button</Text>
      </TouchableOpacity>

      <View style={globalStyles.card}>
        <Text>Another styled card component</Text>
      </View>
    </View>
  );
};

export default StylesDemoScreen;