import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';

const HomeScreen = ({ navigation }) => {
  const screens = [
    { name: 'StylesDemo', title: 'Global Styles Demo' },
    { name: 'DataPassing', title: 'Data Passing Between Routes' },
    { name: 'HooksDemo', title: 'Hooks (useState, useEffect)' },
    { name: 'UseEffectDetailed', title: 'useEffect All Cases' },
    { name: 'ContextDemo', title: 'Context API & useContext' },
    { name: 'FlatListDemo', title: 'FlatList Component' },
    { name: 'AsyncStorageDemo', title: 'AsyncStorage Operations' },
    { name: 'CustomHooks', title: 'Custom Hooks' },
  
    { name: 'SyncAsyncDemo', title: 'Sync vs Async JavaScript' }, 
    { name: 'CallbackHOF', title: 'Callbacks & HOF' }, 
    { name: 'CallbackRules', title: 'Callback Rules' },
    { name: 'CallbackHell', title: 'Callback Hell' }, 
    { name: 'PromiseDemo', title: 'Promises' },
    { name: 'AsyncAwaitDemo', title: 'Async/Await' },
    
    { name: 'TestingInfo', title: 'Testing Information' },
  ];

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>React Native Concepts Demo</Text>
      {screens.map((screen, index) => (
        <TouchableOpacity
          key={index}
          style={globalStyles.button}
          onPress={() => navigation.navigate(screen.name)}
        >
          <Text style={globalStyles.buttonText}>{screen.title}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

export default HomeScreen;