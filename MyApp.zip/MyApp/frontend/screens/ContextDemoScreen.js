import React, { createContext, useContext, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';


const UserContext = createContext();


const UserProvider = ({ children }) => {
  const [user, setUser] = useState({ name: 'John', age: 25 });
  
  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};


const UserProfile = () => {
  const { user, setUser } = useContext(UserContext);

  return (
    <View style={globalStyles.card}>
      <Text>Name: {user.name}</Text>
      <Text>Age: {user.age}</Text>
      <TouchableOpacity 
        style={globalStyles.button}
        onPress={() => setUser({ ...user, age: user.age + 1 })}
      >
        <Text style={globalStyles.buttonText}>Increase Age</Text>
      </TouchableOpacity>
    </View>
  );
};

const ContextDemoScreen = () => {
  return (
    <UserProvider>
      <View style={globalStyles.container}>
        <Text style={globalStyles.title}>Context API Demo</Text>
        <Text>No prop drilling needed!</Text>
        <UserProfile />
      </View>
    </UserProvider>
  );
};

export default ContextDemoScreen;