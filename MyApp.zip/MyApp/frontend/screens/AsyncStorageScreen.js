import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { globalStyles } from '../styles/styles';

const AsyncStorageScreen = () => {
  const [name, setName] = useState('');
  const [savedName, setSavedName] = useState('');

  
  useEffect(() => {
    loadName();
  }, []);

  const saveName = async () => {
    try {
      await AsyncStorage.setItem('userName', name);
      Alert.alert('Success', 'Name saved successfully!');
      setName('');
      loadName();
    } catch (error) {
      console.log('Error saving data', error);
    }
  };

  const loadName = async () => {
    try {
      const value = await AsyncStorage.getItem('userName');
      if (value !== null) {
        setSavedName(value);
      }
    } catch (error) {
      console.log('Error reading data', error);
    }
  };

  const deleteName = async () => {
    try {
      await AsyncStorage.removeItem('userName');
      setSavedName('');
      Alert.alert('Deleted', 'Name removed successfully!');
    } catch (error) {
      console.log('Error deleting data', error);
    }
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>AsyncStorage Demo</Text>
      
      <TextInput
        style={globalStyles.input}
        placeholder="Enter your name"
        value={name}
        onChangeText={setName}
      />
      
      <TouchableOpacity style={globalStyles.button} onPress={saveName}>
        <Text style={globalStyles.buttonText}>Save Name</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={loadName}>
        <Text style={globalStyles.buttonText}>Load Name</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={deleteName}>
        <Text style={globalStyles.buttonText}>Delete Name</Text>
      </TouchableOpacity>

      {savedName ? (
        <View style={globalStyles.card}>
          <Text>Saved Name: {savedName}</Text>
        </View>
      ) : null}
    </View>
  );
};

export default AsyncStorageScreen;