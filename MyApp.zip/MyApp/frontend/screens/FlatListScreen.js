import React from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { globalStyles } from '../styles/styles';

const FlatListScreen = ({ navigation }) => {
  const data = [
    { id: '1', name: 'Apple', type: 'Fruit' },
    { id: '2', name: 'Carrot', type: 'Vegetable' },
    { id: '3', name: 'Banana', type: 'Fruit' },
    { id: '4', name: 'Broccoli', type: 'Vegetable' },
    { id: '5', name: 'Orange', type: 'Fruit' },
  ];

  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={globalStyles.card}
      onPress={() => navigation.navigate('DataPassing', { 
        data: `Selected: ${item.name} (${item.type})` 
      })}
    >
      <Text>{item.name}</Text>
      <Text style={{ color: 'gray' }}>{item.type}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>FlatList Demo</Text>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default FlatListScreen;