import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const CallbackHellScreen = () => {
  const [output, setOutput] = useState([]);

  const addOutput = (text) => {
    setOutput(prev => [...prev, text]);
  };

  const demoCallbackHell = () => {
    setOutput([]);
    addOutput(' Entering Callback Hell...');
    addOutput('(Nested callbacks going deeper →)');
    
    setTimeout(() => {
      addOutput('Step 1: Start app');
      
      setTimeout(() => {
        addOutput('Step 2: Load data');
        
        setTimeout(() => {
          addOutput('Step 3: Show dashboard');
          
          setTimeout(() => {
            addOutput('Step 4: Done!');
            addOutput(' Reached the deepest level!');
          }, 1000);
        }, 1000);
      }, 1000);
    }, 1000);
  };

  const demoPromiseSolution = () => {
    setOutput([]);
    addOutput('✅ Promise Solution to Callback Hell');
    
    const step1 = () => new Promise((resolve) => {
      setTimeout(() => {
        addOutput('Step 1: Start app');
        resolve();
      }, 1000);
    });

    const step2 = () => new Promise((resolve) => {
      setTimeout(() => {
        addOutput('Step 2: Load data');
        resolve();
      }, 1000);
    });

    const step3 = () => new Promise((resolve) => {
      setTimeout(() => {
        addOutput('Step 3: Show dashboard');
        resolve();
      }, 1000);
    });

    const step4 = () => new Promise((resolve) => {
      setTimeout(() => {
        addOutput('Step 4: Done!');
        addOutput('✅ Clean flat structure with Promises');
        resolve();
      }, 1000);
    });

   

    step1()
      .then(step2)
      .then(step3)
      .then(step4)
      .catch(error => addOutput(`Error: ${error}`));
  };

  const demoAsyncAwaitSolution = async () => {
    setOutput([]);
    addOutput(' Async/Await Solution to Callback Hell');
    
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    try {
      await delay(1000);
      addOutput('Step 1: Start app');
      
      await delay(1000);
      addOutput('Step 2: Load data');
      
      await delay(1000);
      addOutput('Step 3: Show dashboard');
      
      await delay(1000);
      addOutput('Step 4: Done!');
      addOutput(' Clean synchronous-like code with Async/Await');
    } catch (error) {
      addOutput(`Error: ${error}`);
    }
  };

  const showProblems = () => {
    setOutput([]);
    addOutput(' Problems with Callback Hell:');
    addOutput('• Hard to read and maintain');
    addOutput('• Difficult to handle errors');
    addOutput('• Code becomes pyramid-shaped');
    addOutput('• Debugging is challenging');
    addOutput('• Hard to add new features');
  };

  const showSolutions = () => {
    setOutput([]);
    addOutput(' Solutions to Callback Hell:');
    addOutput('• Use Promises with .then() chaining');
    addOutput('• Use Async/Await (modern approach)');
    addOutput('• Write small, reusable functions');
    addOutput('• Use Promise.all() for parallel tasks');
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Callback Hell & Solutions</Text>
      
      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>What is Callback Hell?</Text>
        <Text>• Too many nested callbacks</Text>
        <Text>• Each callback depends on previous</Text>
        <Text>• Code becomes hard to read</Text>
        <Text>• Looks like a "pyramid of doom"</Text>
      </View>

      <TouchableOpacity style={globalStyles.button} onPress={demoCallbackHell}>
        <Text style={globalStyles.buttonText}>Demo Callback Hell</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoPromiseSolution}>
        <Text style={globalStyles.buttonText}>Promise Solution</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoAsyncAwaitSolution}>
        <Text style={globalStyles.buttonText}>Async/Await Solution</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={showProblems}>
        <Text style={globalStyles.buttonText}>Callback Hell Problems</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={showSolutions}>
        <Text style={globalStyles.buttonText}>Solutions</Text>
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {output.map((item, index) => (
          <Text key={index} style={globalStyles.card}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default CallbackHellScreen;