import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const CallbackHOFScreen = () => {
  const [output, setOutput] = useState([]);

  const addOutput = (text) => {
    setOutput(prev => [...prev, text]);
  };

 
  const greet = (name) => {
    addOutput(`Hello ${name}`);
  };

 
  const runGreetingFunction = (func) => {
    addOutput('Preparing...');
    func('Laiba'); 
  };

 
  const runGreetingWithDetails = (callback, personName, timeOfDay) => {
    addOutput(`Good ${timeOfDay}!`);
    callback(personName);
  };

  const demoSimpleCallback = () => {
    setOutput([]);
    addOutput('🔹 Simple Callback Demo');
    greet('Laiba'); 
  };

  const demoHOF = () => {
    setOutput([]);
    addOutput('🔹 Higher-Order Function Demo');
    runGreetingFunction(greet); 
  };

  const demoHOFWithArgs = () => {
    setOutput([]);
    addOutput('🔹 HOF with Arguments Demo');
    runGreetingWithDetails(greet, 'Laiba', 'morning');
  };

  const demoAnonymousCallback = () => {
    setOutput([]);
    addOutput('🔹 Anonymous Callback Demo');
    
   
    runGreetingFunction((name) => {
      addOutput(`Anonymous: Hello ${name}`);
    });
  };

  const demoCallbackRules = () => {
    setOutput([]);
    addOutput(' Callback Rules:');
    addOutput(' Correct: runFunc(greet) - no parentheses');
    addOutput(' Wrong: runFunc(greet()) - runs immediately');
    addOutput(' HOF must provide arguments to callback');
    addOutput(' Without arguments, callback gets undefined');
  };

  const demoSetTimeoutCallback = () => {
    setOutput([]);
    addOutput('🔹 setTimeout Callback Demo');
    addOutput('Start');
    
    setTimeout(() => {
      addOutput('Callback executed after 2 seconds!');
    }, 2000);
    
    addOutput('End - printed immediately');
  };

  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Callbacks & Higher-Order Functions</Text>
      
      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Higher-Order Function (HOF):</Text>
        <Text>• Function that receives another function as parameter</Text>
        <Text>• Can use callback like a normal variable</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{fontWeight: 'bold'}}>Callback Function:</Text>
        <Text>• Function passed as argument to HOF</Text>
        <Text>• Executed inside the receiving function</Text>
      </View>

      <TouchableOpacity style={globalStyles.button} onPress={demoSimpleCallback}>
        <Text style={globalStyles.buttonText}>Simple Function Call</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoHOF}>
        <Text style={globalStyles.buttonText}>HOF with Callback</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoHOFWithArgs}>
        <Text style={globalStyles.buttonText}>HOF with Arguments</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoAnonymousCallback}>
        <Text style={globalStyles.buttonText}>Anonymous Callback</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoSetTimeoutCallback}>
        <Text style={globalStyles.buttonText}>setTimeout Callback</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={globalStyles.button} onPress={demoCallbackRules}>
        <Text style={globalStyles.buttonText}>Callback Rules</Text>
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20, maxHeight: 300 }}>
        {output.map((item, index) => (
          <Text key={index} style={globalStyles.card}>{item}</Text>
        ))}
      </ScrollView>
    </View>
  );
};

export default CallbackHOFScreen;