import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { globalStyles } from '../styles/styles';

const TestingInfoScreen = () => {
  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>Testing Information</Text>
      
      <View style={globalStyles.card}>
        <Text style={{ fontWeight: 'bold' }}>Why Testing is Important:</Text>
        <Text>• Catches bugs early</Text>
        <Text>• Keeps app stable when adding features</Text>
        <Text>• Saves time on manual checking</Text>
        <Text>• Makes code reliable</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{ fontWeight: 'bold' }}>Jest Testing Framework:</Text>
        <Text>• Most popular for React Native</Text>
        <Text>• Runs in terminal</Text>
        <Text>• Fast and widely used</Text>
        <Text>• Automatic test file discovery</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{ fontWeight: 'bold' }}>Test File Naming:</Text>
        <Text>• .test.js (most common)</Text>
        <Text>• .spec.js (specification style)</Text>
        <Text>• Jest automatically finds these files</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{ fontWeight: 'bold' }}>Installation Commands:</Text>
        <Text>npm install --save-dev jest jest-expo</Text>
        <Text>npm install --save-dev @testing-library/react-native</Text>
        <Text>npm install --save-dev react-test-renderer@[react-version]</Text>
      </View>

      <View style={globalStyles.card}>
        <Text style={{ fontWeight: 'bold' }}>Example Test File:</Text>
        <Text>HomeScreen.test.js:</Text>
        <Text>{`
import React from 'react';
import { render } from '@testing-library/react-native';
import HomeScreen from '../screens/HomeScreen';

test('HomeScreen renders', () => {
  const screen = render(<HomeScreen />);
  expect(screen).toBeTruthy();
});
        `}</Text>
      </View>
    </ScrollView>
  );
};

export default TestingInfoScreen;