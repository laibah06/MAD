import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
s
import HomeScreen from './screens/HomeScreen';
import StylesDemoScreen from './screens/StylesDemoScreen';
import DataPassingScreen from './screens/DataPassingScreen';
import HooksDemoScreen from './screens/HooksDemoScreen';
import UseEffectDetailedScreen from './screens/UseEffectDetailedScreen';
import ContextDemoScreen from './screens/ContextDemoScreen';
import FlatListScreen from './screens/FlatListScreen';
import AsyncStorageScreen from './screens/AsyncStorageScreen';
import CustomHooksScreen from './screens/CustomHooksScreen';

import SyncAsyncDemoScreen from './screens/SyncAsyncDemoScreen';
import CallbackHOFScreen from './screens/CallbackHOFScreen';
import CallbackRulesScreen from './screens/CallbackRulesScreen';
import CallbackHellScreen from './screens/CallbackHellScreen';
import PromiseDemoScreen from './screens/PromiseDemoScreen';
import AsyncAwaitScreen from './screens/AsyncAwaitScreen';
import TestingInfoScreen from './screens/TestingInfoScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        
        <Stack.Screen name="StylesDemo" component={StylesDemoScreen} />
        <Stack.Screen name="DataPassing" component={DataPassingScreen} />
        <Stack.Screen name="HooksDemo" component={HooksDemoScreen} />
        <Stack.Screen name="UseEffectDetailed" component={UseEffectDetailedScreen} />
        <Stack.Screen name="ContextDemo" component={ContextDemoScreen} />
        <Stack.Screen name="FlatListDemo" component={FlatListScreen} />
        <Stack.Screen name="AsyncStorageDemo" component={AsyncStorageScreen} />
        <Stack.Screen name="CustomHooks" component={CustomHooksScreen} />
        
        <Stack.Screen name="SyncAsyncDemo" component={SyncAsyncDemoScreen} />
        <Stack.Screen name="CallbackHOF" component={CallbackHOFScreen} />
        <Stack.Screen name="CallbackRules" component={CallbackRulesScreen} />
        <Stack.Screen name="CallbackHell" component={CallbackHellScreen} />
        <Stack.Screen name="PromiseDemo" component={PromiseDemoScreen} />
        <Stack.Screen name="AsyncAwaitDemo" component={AsyncAwaitScreen} />
        <Stack.Screen name="TestingInfo" component={TestingInfoScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}