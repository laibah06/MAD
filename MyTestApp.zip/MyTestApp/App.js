import React from 'react';
import HomeScreen from './frontend/screens/HomeScreen';

export default function App() {
  return <HomeScreen />;
}