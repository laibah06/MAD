import React from 'react';
import StorageScreen from './frontend/screens/StorageScreen';

export default function App() {
  return <StorageScreen />;
}