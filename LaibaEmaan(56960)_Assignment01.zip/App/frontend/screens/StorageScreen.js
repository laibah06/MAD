import AsyncStorage from '@react-native-async-storage/async-storage';
import { useState } from 'react';
import { Alert, Button, StyleSheet, Text, TextInput, View, ScrollView } from 'react-native';

const StorageScreen = () => {
  const [storeKey, setStoreKey] = useState('');
  const [storeValue, setStoreValue] = useState('');
  const [fetchKey, setFetchKey] = useState('');
  const [fetchedData, setFetchedData] = useState('');
  const [removeKey, setRemoveKey] = useState('');

  const handleStoreData = async () => {
    if (!storeKey.trim()) {
      Alert.alert('Error', 'Please enter a key');
      return;
    }
    try {
      await AsyncStorage.setItem(storeKey, storeValue);
      Alert.alert('Success', `Data stored for key: "${storeKey}"`);
      setStoreKey('');
      setStoreValue('');
    } catch (e) {
      Alert.alert('Error', 'Failed to save data');
    }
  };

  const handleFetchData = async () => {
    if (!fetchKey.trim()) {
      Alert.alert('Error', 'Please enter a key');
      return;
    }
    try {
      const value = await AsyncStorage.getItem(fetchKey);
      if (value !== null) {
        setFetchedData(value);
        Alert.alert('Success', 'Data fetched!');
      } else {
        setFetchedData('');
        Alert.alert('Info', 'No data found for this key.');
      }
    } catch (e) {
      Alert.alert('Error', 'Failed to fetch data');
    }
  };

  const handleRemoveData = async () => {
    if (!removeKey.trim()) {
      Alert.alert('Error', 'Please enter a key');
      return;
    }
    try {
      await AsyncStorage.removeItem(removeKey);
      Alert.alert('Success', `Data removed for key: "${removeKey}"`);
      setRemoveKey('');
      if (removeKey === fetchKey) {
        setFetchedData('');
      }
    } catch (e) {
      Alert.alert('Error', 'Failed to remove data');
    }
  };

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={true}
    >
      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AsyncStorage Manager</Text>
        <Text style={styles.headerSubtitle}>Store, Retrieve & Manage Data</Text>
      </View>

      {/* STORE DATA SECTION */}
      <View style={[styles.section, styles.storeSection]}>
        <Text style={styles.title}>💾 Store Data</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Key (e.g., userToken)"
          placeholderTextColor="#666"
          value={storeKey}
          onChangeText={setStoreKey}
        />
        <TextInput
          style={styles.input}
          placeholder="Enter Value"
          placeholderTextColor="#666"
          value={storeValue}
          onChangeText={setStoreValue}
        />
        <View style={styles.button}>
          <Button title="Store Data" onPress={handleStoreData} color="#4CAF50" />
        </View>
      </View>

      {/* FETCH DATA SECTION */}
      <View style={[styles.section, styles.fetchSection]}>
        <Text style={styles.title}>🔍 Fetch Data</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Key to Fetch"
          placeholderTextColor="#666"
          value={fetchKey}
          onChangeText={setFetchKey}
        />
        <View style={styles.button}>
          <Button title="Fetch Data" onPress={handleFetchData} color="#2196F3" />
        </View>
        <View style={styles.resultContainer}>
          <Text style={styles.resultLabel}>Fetched Value:</Text>
          <Text style={styles.resultValue}>{fetchedData || 'No data'}</Text>
        </View>
      </View>

      {/* REMOVE DATA SECTION */}
      <View style={[styles.section, styles.removeSection]}>
        <Text style={styles.title}>🗑️ Remove Data</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Key to Remove"
          placeholderTextColor="#666"
          value={removeKey}
          onChangeText={setRemoveKey}
        />
        <View style={styles.button}>
          <Button title="Remove Data" onPress={handleRemoveData} color="#FF5722" />
        </View>
      </View>

      {/* EXTRA SPACE FOR BETTER SCROLLING */}
      <View style={styles.extraSpace} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1,
    backgroundColor: '#ffffff'
  },
  contentContainer: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
    paddingVertical: 20,
    backgroundColor: '#f8f9fa',
    borderRadius: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#6C63FF',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#6C63FF',
    opacity: 0.8
  },
  section: { 
    marginBottom: 25,
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  storeSection: {
    backgroundColor: '#f0f9f0',
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50'
  },
  fetchSection: {
    backgroundColor: '#f0f7ff',
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3'
  },
  removeSection: {
    backgroundColor: '#fff0f0',
    borderLeftWidth: 4,
    borderLeftColor: '#FF5722'
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333'
  },
  input: { 
    borderWidth: 1, 
    borderColor: '#ddd', 
    padding: 12, 
    marginBottom: 15,
    backgroundColor: '#fff',
    borderRadius: 8,
    color: '#333',
    fontSize: 16
  },
  button: {
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 10
  },
  resultContainer: {
    marginTop: 15,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd'
  },
  resultLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5
  },
  resultValue: {
    fontSize: 16,
    color: '#333',
    fontWeight: 'bold'
  },
  extraSpace: {
    height: 50 // Extra space for better scrolling
  }
});

export default StorageScreen;